import pandas as pd
import csv
import matplotlib.pyplot as plot 
import numpy as np
df = pd.read_excel("C:\\Users\\HP\\Desktop\\UPDATED one for screens\\PLC.xlsx")
Solar_gen=df['Solar power']
Max_load=df['Load of Electroliser']
Variable_load=df['Variable load']
wind_gen=df['Wind']
BESS_capacity=df['Battery Capacity'].iloc[0]
Solar_capacity=df['Solar Inverter Capacity']
Wind_capacity=df['Solar Inverter Capacity']
Battery_SOC =df['Battery_initial_SOC'].iloc[0]
Max_SCO=df['Max SOC'].iloc[0]
Min_SOC=df['Min SOC'].iloc[0]
len1=len(Solar_gen)
Delta_P=[]
Discharge_list=[]
Charge_list=[]
curtailment_list=[]
BatterySOC_list=[]
Solar_Setpoint=[]
Wind_Setpoint=[]
Battery_setpoint=[]
Load_Curtailment=[]
Per_load=[]
WPer_load=[]
S_Pqm=[]
W_Pqm=[]
Per_value=df['Percentage']
index=0
for i in Solar_gen:
    if index<=len1:
     a=(Solar_gen[index]/Solar_capacity[0])*100
     b=(wind_gen[index]/Wind_capacity[0])*100
     Per_load.append(a)
     WPer_load.append(b)
     if Per_load[index]>=Per_value[0]:
        sssetpoint=Solar_capacity[0]
        Spqm=Solar_capacity[0]
        S_Pqm.append(Spqm)
        # Solar_Setpoint.append(sssetpoint)
     else:
        sssetpoint=Solar_gen[index]*1.05
        SPqm=Solar_gen[index]
        S_Pqm.append(SPqm)
        # Solar_Setpoint.append(sssetpoint)
     if WPer_load[index]>=Per_value[0]:
        Wssetpoint=Wind_capacity[0]
        WPQM=Wind_capacity[0]
        W_Pqm.append(WPQM)
        # Wind_Setpoint.append(Wssetpoint)
     else:
        Wssetpoint=wind_gen[index]*1.05
        WPQM=wind_gen[index]
        W_Pqm.append(WPQM)
        # Wind_Setpoint.append(Wssetpoint)
    Delp=-S_Pqm[index]-W_Pqm[index]+Max_load[index]+Variable_load[index]
    Delta_P.append(Delp)
    if -BESS_capacity<=Delta_P[index]<=BESS_capacity:
        if Delta_P[index]>=0:
            if Battery_SOC>=Min_SOC:
                Discharge=Delta_P[index] 
                Discharge_list.append(Discharge)
                Charge_list.append(0)
                Battery_setpoint.append(Discharge)
                Battery_SOC=Battery_SOC-(Discharge/BESS_capacity)
                BatterySOC_list.append(Battery_SOC)
                curtailment=0
                Ssetpoint=sssetpoint+curtailment
                curtailment_list.append(curtailment)
                Solar_Setpoint.append(Ssetpoint)
                Wind_Setpoint.append(Wssetpoint)
                # if Ssetpoint>0:
                #     Solar_Setpoint.append(Ssetpoint)
                #     Wind_Setpoint.append(Wssetpoint)
                #     # if Ssetpoint< SPqm:
                #     #     SPqm=Ssetpoint
                #     #     S_Pqm.append(SPqm)
                #     # else:
                #     #     SPqm=Solar_gen[index]
                #     #     S_Pqm.append(SPqm)
                #     # if Wssetpoint< WPQM:
                #     #     WPQM=Wssetpoint
                #     #     W_Pqm.append(WPQM)
                #     # else:
                #     #     WPQM=wind_gen[index]
                #     #     W_Pqm.append(WPQM)                    
                # else:
                #     Wsssetpoint=(0-Ssetpoint)
                #     Ssetpoint=Ssetpoint-Wsssetpoint
                #     Solar_Setpoint.append(Ssetpoint)
                #     Wsetpoint=Wssetpoint+Wsssetpoint
                #     Wind_Setpoint.append(Wsetpoint)
                    # if Ssetpoint< SPqm:
                    #     SPqm=Ssetpoint
                    #     S_Pqm.append(SPqm)
                    # else:
                    #     SPqm=Solar_gen[index]
                    #     S_Pqm.append(SPqm)
                    # if Wssetpoint< WPQM:
                    #     WPQM=Wssetpoint
                    #     W_Pqm.append(WPQM)
                    # else:
                    #     WPQM=wind_gen[index]
                    #     W_Pqm.append(WPQM)    
            else:
                Battery_setpoint.append(0)
                Discharge_list.append(0)
                Charge_list.append(0)
                BatterySOC_list.append(Battery_SOC)
                curtailment=Delta_P[index]
                Ssetpoint=sssetpoint+curtailment
                curtailment_list.append(curtailment) 
                if Ssetpoint>0:
                    Solar_Setpoint.append(Ssetpoint)
                    Wind_Setpoint.append(Wssetpoint)
                    # if Ssetpoint< SPqm:
                    #     SPqm=Ssetpoint
                    #     S_Pqm.append(SPqm)
                    # else:
                    #     SPqm=Solar_gen[index]
                    #     S_Pqm.append(SPqm)
                    # if Wssetpoint< WPQM:
                    #     WPQM=Wssetpoint
                    #     W_Pqm.append(WPQM)
                    # else:
                    #     WPQM=wind_gen[index]
                    #     W_Pqm.append(WPQM) 
                else:
                    Wsssetpoint=(0-Ssetpoint)
                    Ssetpoint=Ssetpoint-Wsssetpoint
                    Solar_Setpoint.append(Ssetpoint)
                    Wsetpoint=Wssetpoint+Wsssetpoint
                    Wind_Setpoint.append(Wsetpoint)
                    # if Ssetpoint< SPqm:
                    #     SPqm=Ssetpoint
                    #     S_Pqm.append(SPqm)
                    # else:
                    #     SPqm=Solar_gen[index]
                    #     S_Pqm.append(SPqm)
                    # if Wssetpoint< WPQM:
                    #     WPQM=Wssetpoint
                    #     W_Pqm.append(WPQM)
                    # else:
                    #     WPQM=wind_gen[index]
                    #     W_Pqm.append(WPQM)   
        else:
            if Delta_P[index]<0 and Battery_SOC<=Max_SCO:
                Charge=Delta_P[index]
                Charge_list.append(Charge)
                Discharge_list.append(0) #UK
                Battery_setpoint.append(Charge)
                Battery_SOC=Battery_SOC-(Charge/BESS_capacity)
                BatterySOC_list.append(Battery_SOC)
                curtailment=0
                Ssetpoint=sssetpoint+curtailment
                curtailment_list.append(curtailment)
                Solar_Setpoint.append(Ssetpoint)
                Wind_Setpoint.append(Wssetpoint)
                # if Ssetpoint< SPqm:
                #     SPqm=Ssetpoint
                #     S_Pqm.append(SPqm)
                # else:
                #     SPqm=Solar_gen[index]
                #     S_Pqm.append(SPqm)
                # if Wssetpoint< WPQM:
                #     WPQM=Wssetpoint
                #     W_Pqm.append(WPQM)
                # else:
                #     WPQM=wind_gen[index]
                #     W_Pqm.append(WPQM)  
            else:
                curtailment=Delta_P[index]
                curtailment_list.append(curtailment)
                Battery_setpoint.append(0)
                Discharge_list.append(0)
                Charge_list.append(0)
                BatterySOC_list.append(Battery_SOC)
                Ssetpoint=sssetpoint+curtailment
                if Ssetpoint>0:
                    Solar_Setpoint.append(Ssetpoint)
                    Wind_Setpoint.append(Wssetpoint)
                    # if Ssetpoint< SPqm:
                    #     SPqm=Ssetpoint
                    #     S_Pqm.append(SPqm)
                    # else:
                    #     SPqm=Solar_gen[index]
                    #     S_Pqm.append(SPqm)
                    # if Wssetpoint< WPQM:
                    #     WPQM=Wssetpoint
                    #     W_Pqm.append(WPQM)
                    # else:
                    #     WPQM=wind_gen[index]
                    #     W_Pqm.append(WPQM) 
                else:
                    Wsssetpoint=(0-Ssetpoint)
                    Ssetpoint=Ssetpoint+Wsssetpoint
                    Solar_Setpoint.append(Ssetpoint)
                    Wsetpoint=Wssetpoint-Wsssetpoint
                    Wind_Setpoint.append(Wsetpoint)
                    # if Ssetpoint< SPqm:
                    #     SPqm=Ssetpoint
                    #     S_Pqm.append(SPqm)
                    # else:
                    #     SPqm=Solar_gen[index]
                    #     S_Pqm.append(SPqm)
                    # if Wsetpoint< WPQM:
                    #     WPQM=Wsetpoint
                    #     W_Pqm.append(WPQM)
                    # else:
                    #     WPQM=wind_gen[index]
                    #     W_Pqm.append(WPQM) 
    index+=1                             
with open('C:\\Users\\HP\\Desktop\\UPDATED one for screens\\Battery_setpoint1.csv', mode='w', newline='') as file:
    wr= csv.writer(file)
    wr.writerow(['Solar gen','wind gen','S_Pqm','W_Pqm','deltap','Solar_Setpoint','Wind_Setpoint','Battery_setpoint','BatterySOC_list','Discharge_list','Charge_list','curtailment_list']) # adding header to output csv
    wr.writerows(zip(Solar_gen,wind_gen,S_Pqm,W_Pqm,Delta_P,Solar_Setpoint,Wind_Setpoint,Battery_setpoint, BatterySOC_list, Discharge_list,Charge_list,curtailment_list))
    print(len(Battery_setpoint))


# x_axis = np.linspace(1,1440)
# plot.plot(x_axis,BatterySOC_list)
# plot.show()'''

